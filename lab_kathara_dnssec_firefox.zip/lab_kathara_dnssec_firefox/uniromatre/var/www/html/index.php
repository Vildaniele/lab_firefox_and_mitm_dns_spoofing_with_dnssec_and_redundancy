<?php
session_start();
$db_file = '/var/www/db/users.json';

// Inizializzazione Database
if (!file_exists($db_file)) {
    if (!is_dir('/var/www/db')) { mkdir('/var/www/db', 0777, true); }
    $initial_data = [
        "500500" => [
            "password" => "Gatto26!",
            "nome" => "Simone",
            "cognome" => "Alessandrini",
            "matricola" => "500500"
        ]
    ];
    file_put_contents($db_file, json_encode($initial_data));
}

$users = json_decode(file_get_contents($db_file), true);
$status = isset($_SESSION['user']) ? "success" : "login";
$logged_user = $_SESSION['user'] ?? null;
$message = "";

if (isset($_GET['page']) && $_GET['page'] == 'profilo' && $logged_user) {
    $status = "profile";
}

if (isset($_POST['do_login'])) {
    $m = trim($_POST['matricola']);
    $p = trim($_POST['password']);
    if (isset($users[$m]) && $users[$m]['password'] === $p) {
        $_SESSION['user'] = $users[$m];
        header("Location: index.php");
        exit();
    } else {
        $message = "<span style='color:#ff4d4d; font-weight:bold;'>Matricola o Password errati!</span>";
    }
}

if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Portale Studente - UniRoma3</title>
    <style>
        body { 
            font-family: 'Segoe UI', Tahoma, sans-serif; 
            margin: 0; 
            min-height: 100vh;
            background-image: linear-gradient(rgba(0, 0, 0, 0.65), rgba(0, 0, 0, 0.65)), url('sfondo.jpg'); 
            background-size: cover; 
            background-position: center; 
            background-attachment: fixed;
            color: white;
            overflow-x: hidden;
        }
        
        /* LOGIN BOX */
        .login-container { display: flex; justify-content: center; align-items: center; height: 100vh; }
        .login-box { 
            background: rgba(255, 255, 255, 0.95); 
            padding: 40px; border-radius: 15px; width: 350px; 
            border-top: 6px solid #004a99; text-align: center; color: #333;
        }

        /* NAVBAR */
        .top-nav { position: fixed; top: 0; right: 0; padding: 20px 30px; z-index: 1000; }
        .user-trigger { 
            background: white; padding: 12px 25px; border-radius: 8px; 
            box-shadow: 0 4px 12px rgba(0,0,0,0.3); font-weight: bold; 
            color: #004a99; cursor: pointer; border: 1px solid #ddd;
            user-select: none;
        }
        .dropdown-menu {
            display: none; position: absolute; right: 30px; top: 75px;
            background: white; min-width: 220px; border-radius: 8px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.4); overflow: hidden;
        }
        .dropdown-menu a {
            display: block; padding: 15px 20px; text-decoration: none; color: #333;
            border-bottom: 1px solid #f0f0f0; transition: 0.2s; font-size: 14px;
        }
        .dropdown-menu a:hover { background-color: #e6f0ff; color: #004a99; }

        /* DASHBOARD GRID */
        .dashboard-container { padding: 120px 20px 50px; max-width: 1000px; margin: 0 auto; text-align: center; }
        .grid-home { 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); 
            gap: 20px; margin-top: 40px; 
        }
        
        .card {
            background: rgba(255, 255, 255, 0.9); 
            padding: 30px 15px; border-radius: 12px;
            cursor: pointer; transition: all 0.3s ease; 
            display: flex; align-items: center; justify-content: center;
            border: 2px solid #004a99; min-height: 100px; color: #004a99;
        }
        .card:hover { 
            background: #004a99; color: white; 
            transform: scale(1.05); box-shadow: 0 10px 20px rgba(0,0,0,0.4);
        }
        .card span { font-weight: bold; text-transform: uppercase; font-size: 13px; text-align: center; }

        /* PROFILE */
        .profile-card { 
            background: rgba(255, 255, 255, 0.95); padding: 40px; border-radius: 15px; 
            max-width: 500px; margin: 150px auto; color: #333; border-left: 10px solid #004a99;
        }
        
        input { width: 100%; padding: 12px; margin: 10px 0; border: 1px solid #ccc; border-radius: 6px; box-sizing: border-box; }
        .btn-blue { width: 100%; padding: 12px; background-color: #004a99; color: white; border: none; border-radius: 6px; cursor: pointer; font-weight: bold; }
    </style>
</head>
<body>

    <?php if ($status == 'login'): ?>
        <div class="login-container">
            <div class="login-box">
                <h1 style="color: #004a99; margin: 0; font-size: 26px;">Roma Tre</h1>
                <p>Accedi ai servizi online</p>
                <form method="POST">
                    <input type="text" name="matricola" placeholder="Matricola" required>
                    <input type="password" name="password" placeholder="Password" required>
                    <button type="submit" name="do_login" class="btn-blue">Entra</button>
                </form>
                <div style="margin-top: 15px;"><?php echo $message; ?></div>
            </div>
        </div>

    <?php elseif ($status == 'success'): ?>
        <div class="top-nav" id="navContainer">
            <div class="user-trigger" id="userTrigger">
                👤 <?php echo htmlspecialchars($logged_user['nome'] . " " . $logged_user['cognome']); ?>
            </div>
            <div class="dropdown-menu" id="dropdownMenu">
                <a href="?page=profilo">👤 Dati Personali</a>
                <a href="#">⚙️ Impostazioni</a>
                <a href="?logout=1" style="color: #d93025; font-weight: bold; border-top: 2px solid #eee;">🚪 Logout</a>
            </div>
        </div>

        <div class="dashboard-container">
            <h1 style="text-shadow: 2px 2px 4px rgba(0,0,0,0.5);">Servizi Online Studenti</h1>
            <div class="grid-home">
                <div class="card"><span>Carriera e Libretto</span></div>
                <div class="card"><span>Tasse e Contributi</span></div>
                <div class="card"><span>Avvisi e News</span></div>
                
                <div class="card"><span>Rinnovo Iscrizione</span></div>
                <div class="card"><span>Certificati</span></div>
                <div class="card"><span>Diritto allo Studio</span></div>
                
                <div class="card"><span>Tirocinio e Stage</span></div>
                <div class="card"><span>Bandi e Concorsi</span></div>
                <div class="card"><span>Immatricolazione</span></div>
            </div>
        </div>

    <?php elseif ($status == 'profile'): ?>
        <div class="profile-card">
            <h2 style="color: #004a99;">Profilo Studente</h2>
            <p><strong>Nome:</strong> <?php echo htmlspecialchars($logged_user['nome']); ?></p>
            <p><strong>Cognome:</strong> <?php echo htmlspecialchars($logged_user['cognome']); ?></p>
            <p><strong>Matricola:</strong> <?php echo htmlspecialchars($logged_user['matricola']); ?></p>
            <button onclick="window.location.href='index.php'" class="btn-blue" style="margin-top: 20px;">Torna alla Dashboard</button>
        </div>
    <?php endif; ?>

    <script>
        const trigger = document.getElementById('userTrigger');
        const menu = document.getElementById('dropdownMenu');
        let closeTimer;

        function showMenu() {
            clearTimeout(closeTimer);
            menu.style.display = 'block';
        }

        function hideMenu() {
            menu.style.display = 'none';
        }

        trigger.addEventListener('mouseenter', showMenu);
        menu.addEventListener('mouseenter', showMenu);

        const startTimer = () => {
            closeTimer = setTimeout(hideMenu, 10000);
        };
        trigger.addEventListener('mouseleave', startTimer);
        menu.addEventListener('mouseleave', startTimer);

        trigger.addEventListener('click', (e) => {
            e.stopPropagation();
            if (menu.style.display === 'block') {
                hideMenu();
            } else {
                showMenu();
            }
        });

        document.addEventListener('click', (e) => {
            if (menu.style.display === 'block' && !menu.contains(e.target) && e.target !== trigger) {
                hideMenu();
            }
        });
    </script>
</body>
</html>